﻿using System.Reflection;

[assembly: AssemblyTitle("RoomMe")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("RoomMe")]
[assembly: AssemblyCopyright("Copyright ©  2019")]
[assembly: AssemblyVersion("1.0.0.*")]

