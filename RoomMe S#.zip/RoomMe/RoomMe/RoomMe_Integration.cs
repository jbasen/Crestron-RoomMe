﻿using System;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.Net.Http;

namespace RoomMe
{
	public delegate void DelegateFn(SimplSharpString data);

	public class RoomMe_Integration
	{
		public DelegateFn Send_Data { get; set; }

		//****************************************************************************************
		// 
		//  RoomMe_Integration	-	constructor
		// 
		//****************************************************************************************
		public RoomMe_Integration()
		{
		}

		#region Declarations
		private string message_type;
		private ushort userid;
		private string userName;
		private string roomName;
		private string sensorid;
		private string event_name;
		private string inControl;
		private string lastInRoom;
		#endregion

		//****************************************************************************************
		// 
		//  Initialize	-	Start HTTP Server
		// 
		//****************************************************************************************
		public void Initialize(int Port)
		{
			//Error Checking
			if (Port == 0)
			{
				CrestronConsole.PrintLine("Invalid Port for RoomMe Receiver Initialization");
				Crestron.SimplSharp.ErrorLog.Error("Invalid Port for RoomMe Receiver Initialization");
				return;
			}
			else
			{
				//CrestronConsole.PrintLine("Port = " + Port);//tester
			}

			//start http server
			try
			{
				HttpServer Server = new HttpServer();
				Server.Port = Port;
				Server.ValidateRequests = false;
				Server.OnHttpRequest += new OnHttpRequestHandler(Server_OnHttpRequest);
				Server.Active = true;
				Server.KeepAlive = true;
			}
			catch (Exception ex)
			{
				CrestronConsole.PrintLine("Failure to Create RoomMe HttpServer on Port" + Port.ToString());
				CrestronConsole.PrintLine(ex.ToString());
				Crestron.SimplSharp.ErrorLog.Error("Failure to Create RoomMe HttpServer on Port" + Port.ToString());
				Crestron.SimplSharp.ErrorLog.Error(ex.ToString());
			}
		}

		//****************************************************************************************
		// 
		//  Server_OnHttpRequest	-	HTTP Server 
		// 
		//****************************************************************************************
		private void Server_OnHttpRequest(object aSender, OnHttpRequestArgs e)
		{
			Parse(e.Request.ContentString);
			//send data back to S+

			if (Send_Data != null)
			{
				Parse(e.Request.ContentString);
			}
			else
			{
				CrestronConsole.PrintLine("ERROR: RoomMe Callback Function is NULL");
				Crestron.SimplSharp.ErrorLog.Error("ERROR: RoomMe Callback Function is NULL");
			}

			//Send Response Back to RoomMe
			e.Response.Header.SetHeaderValue("Content-Type", "text/html");
			e.Response.ResponseText = "OK";
			e.Response.Code = 200;
			e.Response.CloseStream = true;
		}

		//****************************************************************************************
		// 
		//  Parse	-	Parse Data
		// 
		//****************************************************************************************
		private void Parse(string s)
		{
			CrestronConsole.PrintLine("RoomMe - Json = " + s);					//TEST CODE - Display Message Received
			#region Get Message Type
			message_type = Parse_Data_Substring(s, "\"type\"", ":\"", "\"", 0);
			#endregion

			if (message_type == "Event")
			{
				#region RoomMe Event
				//Parse Event Common Data Elements
				userid = Parse_Data_UShort(s, "\"userId\"", ":", 0);
				if (userid != 999)
				{
					userid += 1;	//convert userId from zero based to 1 based values
				}
				userName = Parse_Data_Substring(s, "\"userName\"", ":\"", "\"", 0);
				roomName = Parse_Data_Substring(s, "\"roomName\"", ":\"", "\"", 0);
				sensorid = Parse_Data_Substring(s, "\"sensorId\"", ":\"", "\"", 0);

				//Get data unique to different events
				int index = s.IndexOf("\"event\":{");

				//Parse event name
				event_name = Parse_Data_Substring(s, "\"name\"", ":\"", "\"", index);

				if (event_name == "RoomEntry")
				{
					inControl = Parse_Data_Bool(s, "\"inControl\"", ":", index);
					if (inControl == "true")
					{
						//Send data that New Person in Control of Room to Simpl
						Send_Data("ControlEntry|" + roomName + "|" + userName + "|" + userid.ToString() + "|\r");
					}
					else
					{
						Send_Data("Info|RoomEntry|" + roomName + "|" + userName + "|" + userid.ToString() + "|\r");
					}
				}
				else if (event_name == "RoomExit")
				{
					lastInRoom = Parse_Data_Bool(s, "\"lastInRoom\"", ":", index);
					if (lastInRoom == "true")
					{
						//Send data that last person in room has exited
						Send_Data("LastExit|" + roomName + "|\r");
					}
					else
					{
						Send_Data("Info|RoomExit|" + roomName + "|" + userName + "|" + userid.ToString() + "|\r");
					}
				}
				else if (event_name == "PowerUp")
				{
					//Nothing to do at powerup based on current functionality
					Send_Data("Info|PowerUp|" + roomName + "|\r");
				}
				else if (event_name == "LowBattery")
				{
					//Send data that sensor is reporting low battery
					Send_Data("LowBattery|" + roomName + "|\r");
				}
				else
				{
					CrestronConsole.PrintLine("ERROR: RoomMe - Invalid Event Type - " + event_name);
					Crestron.SimplSharp.ErrorLog.Error("ERROR: RoomMe - Invalid Event Type - " + event_name);

				}
				#endregion
			}
			else if (message_type == "Database")
			{
				#region Database
				//TODO - Parse Database for implementing more advanced functionality
				CrestronConsole.PrintLine("RoomMe - Database");//tester
				#endregion
			}
			else
			{
				CrestronConsole.PrintLine("ERROR: RoomMe - Invalid Message Type - " + message_type);
				Crestron.SimplSharp.ErrorLog.Error("ERROR: RoomMe - Invalid Message Type - " + message_type);
			}

		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Substring(string s, string id, string data_starting_chars, string data_ending_chars1, int start_index)
		{
			int index1, index2;
			string id1 = id + data_starting_chars;

			//get index to start of value
			index1 = s.IndexOf(id1, start_index);
			if (index1 == -1)
			{
				CrestronConsole.PrintLine("RoomMe-Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += +id1.Length;
			}

			//get index to end of value - RoomMe JSON isn't consistent so multiple possible terminations
			index2 = s.IndexOf(data_ending_chars1, (index1 + 1));							
			if (index2 == -1)
			{
				
				CrestronConsole.PrintLine("RoomMe-Unable to Locate terminating " + data_ending_chars1 + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}
		
		//****************************************************************************************
		// 
		//  Parse_Data_Bool	-	Parse Boolean Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Bool(string s, string id, string data_starting_chars, int start_index)
		{
			int index1, index2;
			string id1 = id + data_starting_chars;

			//get index to start of value
			index1 = s.IndexOf(id1, start_index);
			if (index1 == -1)
			{
				CrestronConsole.PrintLine("RoomMe-Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += +id1.Length;
			}

			//get index to end of value - RoomMe JSON isn't consistent so multiple possible terminations
			index2 = s.IndexOf("e", (index1 + 1));
			if (index2 == -1)
			{

				CrestronConsole.PrintLine("RoomMe-Unable to Locate end of boolean for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1) + "e";
		}
		
		//****************************************************************************************
		// 
		//  Parse_Data_UShort	-	Parse short Data Element from Json
		// 
		//****************************************************************************************
		private ushort Parse_Data_UShort(string s, string id, string data_starting_chars, int start_index)
		{
			int index1;
			int digit_count;
			string id1 = id + data_starting_chars;

			//get index to start of value
			index1 = s.IndexOf(id1, start_index);
			if (index1 == -1)
			{
				CrestronConsole.PrintLine("RoomMe-Unable to Locate " + id + " in " + s);
				return 999;
			}
			else
			{
				index1 += +id1.Length;
			}

			//get numberr of digits is numerical value
			string s1 = s.Substring(index1);
			digit_count = 0;
			foreach (char c in s1)
			{
				if (char.IsDigit(c))
				{
					digit_count++;
				}
				else
				{
					break;
				}
			}
			
			//parse digits
			if (digit_count != 0)
			{
				s1 = s1.Substring(0, digit_count);
				return ushort.Parse(s1);
			}
			else
			{
				CrestronConsole.PrintLine("RoomMe-Unable to parse ushort for " + id + " in " + s);
				return 999;
			}
		}
	
	}
}
